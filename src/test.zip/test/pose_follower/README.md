pose_follower
=============

A implementation of a local planner that attempts to follow a plan as closely
as possible.
